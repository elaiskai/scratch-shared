BOX DIELINE v2 - OPEN QUESTIONS (Vol. I)

Interior: 150 x 108 x 15 mm
Fits 30 A6 cards (105 x 148 mm)

FILES
  box_dieline.svg          vector dieline + design (place in InDesign)
  box_dieline_raster.pdf   raster fallback
  box_dieline_preview.png  flat preview
  fonts/                   Cinzel + EB Garamond TTF files (open source)

INSTALL FONTS FIRST
  Double-click each .ttf in the fonts/ folder to install:
    Cinzel.ttf              - mysterious classical caps (title, spine)
    EBGaramond.ttf          - body serif
    EBGaramond-Italic.ttf   - italic subtitle
  Restart InDesign after install. Otherwise it will substitute.

DESIGN ELEMENTS (v2)
  LID    decorative double frame + corner diamonds
         central QUINCUNX (5-dot dice pattern = chance/inquiry symbol)
         Cinzel title 'OPEN QVESTIONS' (Roman U as V for ancient feel)
         italic subtitle 'thirty inquiries without endings'
         subtle dot grid background, decorative ornament lines
         footer 'MMXXVI'
  SPINE  triple horizontal rules top + bottom
         Cinzel title centered, Roman volume/count markers (I / XXX)
         small diamond accents
  BASE   large central quincunx + 2 concentric rings
         VOLVMEN I OF II + companion to PROVISIONAL ANSWERS (italic)
         printer's mark monogram (OQ) bottom-right
         EDITIO PRINCEPS bottom-left
         subtler dot grid background
  EDGES  18 page edges per wall (vs 34 before), darker brown,
         grouped 5-8-5 to simulate book signatures

WHY THE LID READS UPSIDE-DOWN IN THE FLAT
The lid folds 180 deg over when closing. Drawing the lid art
rotated 180 in the flat = artwork appears right-side-up on the
assembled box. The spine + base read normally.

WORKFLOW
  1. Install fonts (double-click TTFs)
  2. Open InDesign, New A3 portrait (297 x 420 mm)
  3. File > Place > box_dieline.svg, single CLICK to place at 100%
  4. Verify W: 220 mm, H: 298 mm
  5. SVG has two groups: 'design' and 'dieline'. Hide 'dieline'
     before final print if you only want the design printed.
  6. Print 100% scale on 300-400 gsm cardstock
  7. Cut along black solid, score and fold along red dashed,
     glue ears (blue dashed) to inside of front/back walls
  8. Close lid, tuck flap into front slot
