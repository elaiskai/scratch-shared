BOX DIELINE - OPEN QUESTIONS (Vol. I)

Interior: 150 x 108 x 15 mm
Fits 30 A6 cards (105 x 148 mm)

FILES
  box_dieline.svg          vector, place in InDesign (File > Place, single click)
  box_dieline_raster.pdf   high-res raster fallback
  box_dieline_preview.png  flat preview

WHY THE LID TEXT LOOKS UPSIDE-DOWN IN THE FLAT
The lid folds over 180 degrees when closing. Drawing the lid art
rotated 180 in the flat means the artwork appears right-side-up
on the assembled box. This is correct - do not flip it.

The spine (back wall) and base read normally in the flat.

PANELS
  LID            front cover, "OPEN QUESTIONS"
  BACK WALL      spine with title + VOL marker + card count (XXX = 30)
  FRONT WALL     fore-edge, simulated page edges
  LEFT / RIGHT   top/bottom edges, simulated page edges
  BASE           back cover, 3x3 dot grid + companion volume note

WORKFLOW
  1. New InDesign A3 portrait (297 x 420 mm)
  2. File > Place > box_dieline.svg
  3. Single CLICK to place at 100% (do not drag)
  4. Verify W: 220 mm, H: 298 mm
  5. Print 100% scale on 300-400 gsm cardstock
  6. Cut along black solid lines
  7. Score and fold along red dashed lines
  8. Glue corner ears (blue dashed edges) inside front/back walls
  9. Close lid, tuck flap into front slot

The dieline lines (cut/fold/glue) are in a separate SVG group
'dieline'. Hide or delete this group before final print if you
want only the design to show. Keep them visible to mark the
cut/score guides.
