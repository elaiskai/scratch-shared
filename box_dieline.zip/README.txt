BOX DIELINE FILES

interior 150 x 108 x 15 mm - fits 30 A6 cards (105 x 148 mm)

box_dieline.svg          - vector, best for InDesign (File > Place)
box_dieline_vector.pdf   - hand-built vector PDF
box_dieline_raster.pdf   - high-res raster PDF (fallback)
box_dieline_preview.png  - quick preview, also placeable as raster

For InDesign:
1. Create new A3 portrait document (297 x 420 mm)
2. File > Place > pick SVG (preferred) or one of the PDFs
3. Single CLICK on canvas to place at 100% (do not drag - that resizes)
4. Verify dimensions: selected object should be 220 x 298 mm
5. Print at 100% scale, no "fit to page"

Legend in the dieline:
- black solid = CUT lines
- red dashed  = FOLD lines (panel hinges)
- blue dashed = GLUE TAB edges (ears glue to inside of front/back walls)

Material: 1.5 mm corrugated (E-flute) or 300-400 gsm cardstock.
Score folds with a bone folder before creasing.
