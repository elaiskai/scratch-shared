BOX DIELINE v3 - OPEN QUESTIONS (Baltic folk edition)

Interior: 150 x 108 x 15 mm
Fits 30 A6 cards (105 x 148 mm)

FILES
  box_dieline.svg          vector + design (place in InDesign)
  box_dieline_raster.pdf   raster fallback
  box_dieline_preview.png  flat preview
  fonts/                   Cinzel + EB Garamond TTFs

INSTALL FONTS FIRST
  Double-click each .ttf in fonts/ to install. Restart InDesign.

BALTIC FOLK ELEMENTS (v3)
  Background  warm cream linen tone (replaces white)
              subtle all-over diamond grid pattern
  LID         decorative double border + 4 corner saulutes (sun stars)
              top + bottom folk bands with diamond-with-X motifs
              central QUINCUNX (5-dot dice = chance)
              Cinzel title 'OPEN QVESTIONS' + italic subtitle
  SPINE       saulutes between Roman I, title, XXX
  BASE        top folk band of suns + central quincunx with rings
              VOLVMEN I OF II + companion to PROVISIONAL ANSWERS
              printer's mark OQ + EDITIO PRINCEPS

WHY LID READS UPSIDE-DOWN IN FLAT
The lid folds 180 on closing - drawing it rotated in flat means
the artwork appears right-side-up on the assembled box.

WORKFLOW
  1. Install fonts
  2. InDesign New A3 portrait (297 x 420)
  3. File > Place > box_dieline.svg, single CLICK at 100%
  4. Verify W: 220 mm, H: 298 mm
  5. SVG groups: 'design' (artwork) + 'dieline' (cut/fold/glue marks)
     Hide 'dieline' before final print if you want only the design.
  6. Print 100% on 300-400 gsm cardstock
  7. Cut along black solid, fold red dashed, glue ears (blue dashed)
